@include('includes.head')

@yield('content')

@include('includes.footer')