@include('includes.head')
@include('includes.header')
@include('includes.sidebar')
@yield('content')

@include('includes.footer')