
<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <h3 class="text-uppercase color-bbc">Supplier Quotation</h3>
                    <div class="col-sm-10 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>PR ID</th>
                                    <th>PR Type</th>
                                    <th>Items Name</th>
                                    <th>Item Code</th>
                                    <th>Quantity<th>
                                    <?php if(Auth::user()->role == 'manager' || Auth::user()->role == 'executive'): ?><th>Unit Price</th><?php endif; ?>
                                    <th>Supplier Name</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php $__currentLoopData = $q->qr_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($qr->pr_id); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $q->qr_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($qr->pr_type); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $q->item_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($qr->item_name); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $q->item_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($qr->item_no); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $q->item_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($qr->quantity); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td></td>
                                        <?php if(Auth::user()->role == 'manager' || Auth::user()->role == 'executive'): ?><td><?php if(Auth::user()->role == $q->show_price || Auth::user()->role == $q->show_price_e): ?><?php echo e($q->unit_price); ?><?php endif; ?></td><?php endif; ?>
                                        <td><?php echo e($q->supplier_details->name); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>