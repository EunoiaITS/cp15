
<?php $__env->startSection('content'); ?>
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <div class="col-sm-10 padding-left-0">
                        <div class="create-qr qr-overfollow">
                            <h3 class="text-uppercase color-bbc">Quotation Requisition Upload</h3>
                            <?php if(session()->has('success-message')): ?>
                                <p class="alert alert-success">
                                    <?php echo e(session()->get('success-message')); ?>

                                </p>
                            <?php endif; ?>
                            <form action="<?php echo e(url('/qr-orders/import-data')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <label>Upload File</label>
                                <input type="file" name="file" required><br/>
                                <input type="submit" value="upload">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>