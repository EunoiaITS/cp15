<?php $__env->startSection('content'); ?>
<!-- content area-->
<div class="bbc-content-area mcw">
    <div class="container">
        <div class="row">
            <div class="col-sm-11 col-sm-offset-1">
                <div class="col-sm-10 padding-left-0">
                    <div class="create-qr qr-overfollow">
                        <h3 class="text-uppercase color-bbc">Create QR Order</h3>
                        <?php if(session()->has('error')): ?>
                            <p class="alert alert-success">
                                <?php echo e(session()->get('error')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if(session()->has('error-message')): ?>
                            <p class="alert alert-danger">
                                <?php echo e(session()->get('error-message')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if(session()->has('success-message')): ?>
                            <p class="alert alert-success">
                                <?php echo e(session()->get('success-message')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="alert alert-danger">
                                    <?php echo e($error); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <form action="<?php echo e(url('/qr-orders/add-qr-order')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                            <div class="form-group clearfix">
                                <label for="pr-id" class="label-d">PR ID <span class="fright">:</span></label>
                                <input type="text" name="pr_id" class="form-control from-qr" id="pr-id" required>
                                <?php if($errors->any()): ?><p class="text-muted small text-danger"><?php echo e($errors->first('pr_id')); ?></p><?php endif; ?>
                            </div>
                            <div class="form-group clearfix">
                                <label for="pr-type" class="label-d">PR Type <span class="fright">:</span></label>
                                <input type="text" name="pr_type" class="form-control from-qr" id="pr-type" required>
                                <?php if($errors->any()): ?><p class="text-muted small text-danger"><?php echo e($errors->first('pr_type')); ?></p><?php endif; ?>
                            </div>
                            <div class="form-group live-search">
                                <label for="pr-catagory" class="label-d">Category <span class="fright">:</span></label>
                                <select data-live-search="true" name="category" class="selectpicker category" id="pr-catagory" required>
                                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->any()): ?><p class="text-muted small text-danger"><?php echo e($errors->first('category')); ?></p><?php endif; ?>
                            </div>
                            <input type="hidden" name="status" value="requested">
                            <div id="add-item-table" class="col-sm-10 table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Items Name</th>
                                        <th>Items Code</th>
                                        <th>Quantity</th>
                                        <th>Remove</th>
                                    </tr>
                                    </thead>
                                    <tbody id="add-item-table-item">
                                    <tr>
                                        <td>1</td>
                                        <td><input name="item_name1" type="text" class="form-control from-qr" id="pr-item-name" name="prItem" required></td>
                                        <td><input name="item_no1" type="text" class="form-control from-qr" id="pr-item-code" name="prItemcode" required></td>
                                        <td><input name="quantity1" type="text" class="form-control from-qr" id="pr-quantity" name="prQuantity" required></td>
                                        <td><button type="button" class="btn btn-primary"><i class="fa fa-times"></i></button></td>
                                        <input type="hidden" name="count" value="1">
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <button type="button" id="add-item-create" class="btn btn-info btn-price add-item-qe">Add Item</button>

                            <div class="col-sm-12">
                                <div class="btn-button-group clearfix">
                                    <button type="submit" class="btn btn-info btn-price">Create</button>
                                    <button type="button" onclick="location.reload()" class="btn btn-info btn-popup close">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>