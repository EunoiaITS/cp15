<script>
    function duplicateEmail(element){
        var email = $(element).val();
        $.ajax({
            type: "GET",
            url: '<?php echo e(url('/checkemail')); ?>',
            data: {email:email},
            dataType: "json",
            success: function(res) {
                if(res.exists){
                    $('#email-error').text('Email Already Exists ! Please Choose Another !');
                }else{
                    //alert('false');
                }
            },
            error: function (jqXHR, exception) {

            }
        });
    }
</script>