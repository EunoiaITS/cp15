<?php $__env->startSection('content'); ?>
<!-- content area-->

<div class="bbc-content-area mcw">
    <div class="container">
        <div class="row">
            <div class="col-sm-11 col-sm-offset-1">
                <div class="col-sm-10 padding-left-0">
                    <div class="create-qr clearfix">
                        <h3 class="text-uppercase color-bbc">Create Users</h3>
                        <?php if(session()->has('success-message')): ?>
                            <p class="alert alert-success">
                                <?php echo e(session()->get('success-message')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="alert alert-danger">
                                    <?php echo e($error); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <form action="<?php echo e(url('superuser')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group clearfix">
                                <label for="supplier-name" class="label-d">Name <span class="fright">:</span></label>
                                <input name="name" type="text" class="form-control from-qr" id="supplier-name" value="<?php echo e(old('name')); ?>" required="">
                                <?php if($errors->any()): ?><p class="text-muted small text-danger"><?php echo e($errors->first('name')); ?></p><?php endif; ?>
                            </div>
                            <div class="form-group clearfix">
                                <label for="catagory-catagory" class="label-d">Role <span class="fright">:</span></label>
                                <select name="role" class="form-control from-qr" id="catagory-catagory">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role); ?>"><?php echo e($role); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group clearfix">
                                <label for="pr-email" class="label-d">Email Address <span class="fright">:</span></label>
                                <input name="email" type="email" class="form-control from-qr" id="pr-email" value="<?php echo e(old('email')); ?>" required="">
                                <?php if($errors->any()): ?><p class="text-muted small text-danger"><?php echo e($errors->first('email')); ?></p><?php endif; ?>
                            </div>
                            <div class="form-group clearfix">
                                <label for="pr-contact" class="label-d">Password <span class="fright">:</span></label>
                                <input name="password" type="password"  class="form-control from-qr" id="pr-contact">
                                <?php if($errors->any()): ?><p class="text-muted small text-danger"><?php echo e($errors->first('password')); ?></p><?php endif; ?>
                            </div>
                            <div class="col-sm-9">
                                <button type="submit" class="btn btn-info btn-price" style="float: right;">Add User</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>