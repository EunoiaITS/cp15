<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-sm-offset-0">
                    <h3 class="text-uppercase color-bbc">Quotation Approval</h3>
                    <?php if(session()->has('success-message')): ?>
                    <p class="alert alert-success">
                        <?php echo e(session()->get('success-message')); ?>

                    </p>
                    <?php endif; ?>
                    <?php if(session()->has('error-message')): ?>
                    <p class="alert alert-danger">
                        <?php echo e(session()->get('error-message')); ?>

                    </p>
                    <?php endif; ?>
                    <div class="col-sm-11 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>PR ID</th>
                                    <th>PR Type</th>
                                    <th>Issue Date</th>
                                    <th>End Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $count = 0; ?>
                                <?php $__currentLoopData = $allInvites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($invite->invited) && $invite->invited == 'yes'): ?>
                                        <?php $count++; ?>
                                        <tr>
                                            <td><?php echo e($count); ?></td>
                                            <td><a style="cursor: pointer" class="pr-modal" rel="<?php echo e($count); ?>" data-toggle="modal" data-target="#myModal<?php echo e($count); ?>"><?php echo e($invite->qr_details->pr_id); ?></a></td>
                                            <td><?php echo e($invite->qr_details->pr_type); ?></td>
                                            <td><?php echo e(date('d-M-Y', strtotime($invite->start_date))); ?></td>
                                            <td><?php echo e(date('d-M-Y', strtotime($invite->end_date))); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- pagination -->
                    <div class="col-sm-10">
                        <div class="float-pagination">
                            <nav aria-label="Page navigation example">
                                <?php echo e($allInvites->links()); ?>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--
   PR ID popup content
   ========================-->
    <?php $j=0;?>
    <?php $__currentLoopData = $allInvites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($invite->invited) && $invite->invited == 'yes'): ?>
        <?php $j++?>
    <div id="myModal<?php echo e($j); ?>" class="popup-prid-comparison">
        <form action="<?php echo e(url('/approve-quotations')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <div class="popup-base">
            <div class="search-popup">
                <i class="close fa fa-remove" data-dismiss="modal"></i>
                <div class="row">
                    <div class="search-destination">
                        <h2 class="pr-title"><span class="pr-id">PR ID: <?php echo e($invite->qr_details->pr_id); ?></span><span class="prtext"></span></h2>
                    </div>
                    <!-- header got seach area -->
                    <div class="popup-got-search popup-pie clearfix">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th style="text-align: center;">No</th>
                                    <th style="text-align: center;">Item Code</th>
                                    <th style="text-align: center;">Item Name</th>
                                    <th style="text-align: center;">Quantity</th>
                                    <th style="text-align: center;">Unit Price</th>
                                    <th style="text-align: center;">Supplier Name</th>
                                    <th style="text-align: center;">File (BBC)</th>
                                    <th style="text-align: center;">Place of part origin</th>
                                    <th style="text-align: center;">Genuine</th>
                                    <th style="text-align: center;">OEM</th>
                                    <th style="text-align: center;">Brand</th>
                                    <th style="text-align: center;">Deliver Date</th>
                                    <th style="text-align: center;">Comment (Supplier)</th>
                                    <th style="text-align: center;">File (Supplier)</th>
                                    <th style="text-align: center;">Comment (Director)</th>
                                    <th style="text-align: center;">Price Compare</th>
                                    <th style="text-align: center;">To Approve</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $c = 0;?>
                                <?php $__currentLoopData = $invite->qr_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($qr->ex) && ($qr->ex == 'yes')): ?>
                                        <?php if(isset($qr->supplierQuote)): ?>
                                            <?php $__currentLoopData = $qr->supplierQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $c ++;?>
                                <tr>
                                    <td style="text-align: center;"><?php echo e($c); ?></td>
                                    <td style="text-align: center;"><?php echo e($qr->item_no); ?></td>
                                    <td style="text-align: center;" id="item-name-<?php echo e($sq->id); ?>"><?php echo e($qr->item_name); ?></td>
                                    <td style="text-align: center;"><?php echo e($qr->quantity); ?></td>
                                    <td style="text-align: center;" id="unit-price-<?php echo e($sq->id); ?>" class="up-htl"><?php echo e($sq->unit_price); ?></td>
                                    <td style="text-align: center;" id="supplier-name-<?php echo e($sq->id); ?>"><?php echo e($sq->sup_details->name); ?></td>
                                    <td style="text-align: center;"><a href="<?php if($qr->item_file != null): ?><?php echo e(asset('public/uploads/items/'.$qr->item_file )); ?><?php endif; ?>" target="_blank"><?php if($qr->item_file != null){echo "View";}?></a></td>
                                    <td style="text-align: center;"><?php echo e($sq->origin); ?></td>
                                    <td style="text-align: center;"><?php echo e($sq->genuine); ?></td>
                                    <td style="text-align: center;"><?php echo e($sq->oem); ?></td>
                                    <td style="text-align: center;"><?php echo e($sq->brand); ?></td>
                                    <td style="text-align: center;"><?php echo e($sq->delivery_date); ?></td>
                                    <td style="text-align: center;"><?php echo e($sq->comment); ?></td>
                                    <td style="text-align: center;"><a href="<?php if($sq->file != null): ?><?php echo e(URL::asset('/public/uploads/suppliers/'.$sq->file)); ?><?php endif; ?>" target="_blank"><?php if($sq->file != null){echo "View";}?></a></td>
                                    <td style="text-align: center;"><input type="text" name="dir_comment"></td>
                                    <td style="text-align: center;">
                                        <label>
                                            <input type="checkbox" rel="<?php echo e($sq->id); ?>" class="select-multiple <?php echo e($qr->item_no); ?> select-items<?php echo e($j); ?>" id="<?php echo e($qr->item_no); ?><?php echo e($j); ?>" value="<?php echo e($qr->item_no); ?>">
                                        </label>
                                    </td>
                                    <td style="text-align: center;">
                                        <label>
                                            <input type="checkbox" rel="<?php echo e($sq->id); ?>" name="state<?php echo e($sq->id); ?>">
                                        </label>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div><!--// end header got search area -->
                    <div class="btn-button-group clearfix">
                        <button type="button" class="btn btn-info btn-price open-popup-comp price-compare">Price Comparison</button>
                        <button type="submit" class="btn btn-info btn-price approve">Approve</button>
                    </div>
                </div>
            </div>
        </div>
      </form>
    </div><!-- Popup -->
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--
price comparison popup
========================-->
<div class="popup-wrapper-compa">
    <div class="popup-base">
        <div class="search-popup">
            <i class="close fa fa-remove"></i>
            <div class="row">
                <div class="search-destination">
                    <h2 class="search-title pie-search">Price Comparison</h2>
                </div>
                <!-- header got seach area -->
                <div class="popup-got-search popup-pie clearfix" id="item-chart">
                    <!-- Pie chart -->
                    <div id="canvas-holder">
                        <p class="text-center">Item 1</p>
                        <canvas id="chart-area"/>
                    </div>
                    <div id="canvas-holder">
                        <p class="text-center">Item 2</p>
                        <canvas id="chart-area2" />
                    </div>
                    <!-- Pie chart -->
                    <div id="canvas-holder">
                        <p class="text-center">Item 3</p>
                        <canvas id="chart-area3"/>
                    </div>
                    <div id="canvas-holder">
                        <p class="text-center">Item 4</p>
                        <canvas id="chart-area4" />
                    </div>
                    <div class="clearfix">
                    </div>
                </div><!--// end header got search area -->
                <button class="btn btn-info btn-popup close-comp">Close</button>
            </div>
        </div>
    </div>
</div><!-- Popup -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>