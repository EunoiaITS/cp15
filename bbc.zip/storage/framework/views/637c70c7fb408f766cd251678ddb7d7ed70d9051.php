<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <?php if(session()->has('error-message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(session()->get('error-message')); ?>

                        </p>
                    <?php endif; ?>
                    <h3 class="text-uppercase color-bbc">Log</h3>
                    <div class="col-sm-10 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Serial No</th>
                                    <th>PR ID</th>
                                    <th>Created By</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Supplier</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($page != 0): ?>
                                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($start); ?></td>
                                            <td><?php echo e($log->details->pr_id); ?></td>
                                            <td><?php echo e($log->details->created_by); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($log->details->created_at))); ?></td>
                                            <td><?php echo e(date('G:i:s A', strtotime($log->details->created_at))); ?></td>
                                            <td><?php echo e($log->name); ?></td>
                                        </tr>
                                        <?php  $start ++  ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-sm-10">
                        <div class="float-pagination">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <?php if($page != 0): ?>
                                        <li class="page-item <?php if($current == 1): ?><?php echo e('disabled'); ?><?php endif; ?>"><a class="page-link" href="?page=1"><i class="fa fa-angle-left"></i></a></li>
                                        <?php for($i = 1; $i <= $page; $i++): ?>
                                            <li class="page-item <?php if($current == $i): ?><?php echo e('active'); ?><?php endif; ?>"><a class="page-link" href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
                                        <?php endfor; ?>
                                        <li class="page-item <?php if($current == $page): ?><?php echo e('disabled'); ?><?php endif; ?>"><a class="page-link" href="?page=<?php echo e($page); ?>"><i class="fa fa-angle-right"></i></a></li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>