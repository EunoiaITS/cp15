<?php 
foreach ($results as $res => $rs){
    echo "<pre>";
    print_r($rs);
    echo "</pre>";
}
     ?>

