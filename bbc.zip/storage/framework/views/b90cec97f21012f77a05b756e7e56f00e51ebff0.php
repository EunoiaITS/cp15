<?php $__env->startSection('content'); ?>
<!-- content area-->
<div class="bbc-content-area mcw">
    <div class="container">
        <div class="row">
            <div class="col-sm-11 col-sm-offset-1">
                <h3 class="text-uppercase color-bbc">View Supplier List</h3>
                <?php if(session()->has('success-message')): ?>
                    <p class="alert alert-success">
                        <?php echo e(session()->get('success-message')); ?>

                    </p>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger">
                            <?php echo e($error); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <!-- fliter button: new added -->
                <div class="supplier-filter-option">
                    <select class="selectfilter" title="Filter">
                        <option class="asc" value="ascending">Ascending A-Z</option>
                        <option class="desc" value="descending">Descending Z-A</option>
                    </select>
                </div>
                <div class="col-sm-10 padding-left-0">
                    <div class="table table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>Supplier Name</th>
                                <th>Category</th>
                                <th>Email Address</th>
                                <th>Contact</th>
                                <th>Edit/Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td id="name<?php echo e($res->id); ?>"><?php echo e($res->name); ?></td>
                                <td id="category<?php echo e($res->id); ?>" rel="<?php echo e($res->cat->id); ?>"><?php echo e($res->cat->category); ?></td>
                                <td id="email<?php echo e($res->id); ?>"><?php echo e($res->email); ?></td>
                                <td id="contact<?php echo e($res->id); ?>"><?php $__currentLoopData = $res->info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($in->contact); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                <td><button rel="<?php echo e($res->id); ?>" id="edit<?php echo e($res->id); ?>" class="btn btn-info btn-view-table open-popup popup-left">Edit</button>
                                    <button rel="<?php echo e($res->id); ?>" id="delete<?php echo e($res->id); ?>" class="btn btn-info btn-view-table open-popup-delete">Delete</button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- pagination -->
            <div class="col-sm-10">
                <div class="float-pagination">
                    <nav aria-label="Page navigation example">
                        <?php echo e($result->appends([ 'order' => $cur_order ])->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<!--=============
edit qr popup
==================-->
<div class="popup-wrapper-view">
    <div class="popup-base">
        <div class="search-popup">
            <i class="close fa fa-remove"></i>
            <div class="row">
                <div class="search-destination">
                    <h2 class="search-title">Edit Supplier</h2>
                </div>
                <!-- header got seach area -->
                <div class="popup-got-search">
                    <form action="<?php echo e(url('suppliers/edit-supplier')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group clearfix">
                            <label for="supplier-name" class="label-d">Supplier Name <span class="fright">:</span></label>
                            <input type="text" name="name" class="form-control from-qr" id="supplier-name" value="">
                        </div>
                        <div class="form-group clearfix">
                            <label for="sup-category" class="label-d">Category <span class="fright">:</span></label>
                            <select name="category" class="form-control from-qr" id="sup-category">
                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group clearfix">
                            <label for="sup-email" class="label-d">Email Address <span class="fright">:</span></label>
                            <input type="text" name="email" class="form-control from-qr" id="sup-email">
                        </div>
                        <div class="form-group clearfix">
                            <label for="sup-contact" class="label-d">Contact <span class="fright">:</span></label>
                            <input type="text" name="contact" class="form-control from-qr" id="sup-contact">
                        </div>
                        <input type="hidden" name="user_id" id="user_id">
                        <div class="col-sm-12">
                            <div class="btn-button-group clearfix">
                                <button type="submit" class="btn btn-info btn-price">Save</button>
                                <button type="button" class="btn btn-info btn-popup close">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div><!--// end header got search area -->
            </div>
        </div>
    </div>
</div><!-- Popup -->

<!--
delete popup
========================-->
<div class="popup-wrapper-delete">
    <div class="popup-base">
        <div class="search-popup">
            <i class="close fa fa-remove"></i>
            <div class="row">
                <div class="search-destination">
                    <h2 class="search-title">Delete Supplier</h2>
                </div>
                <form action="<?php echo e(url('suppliers/delete-supplier')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="user_id" id="delete_user_id">
                <!-- header got seach area -->
                <div class="popup-got-search">
                    <p>Confirm to delete the Supplier from the view Supplier list ?</p>
                </div><!--// end header got search area -->
                <div class="col-sm-12">
                    <div class="btn-button-group clearfix">
                        <button type="submit" class="btn btn-info btn-price">Delete</button>
                        <button type="button" class="btn btn-info btn-popup close">Cancel</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div><!-- Popup -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>