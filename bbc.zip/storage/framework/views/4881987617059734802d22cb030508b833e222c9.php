<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <form action="<?php echo e(url('/allow-price-show')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                <div class="col-sm-11 col-sm-offset-1">
                    <h3 class="text-uppercase color-bbc">Price View Approval</h3>
                    <?php if(session()->has('success-message')): ?>
                        <p class="alert alert-success">
                            <?php echo e(session()->get('success-message')); ?>

                        </p>
                    <?php endif; ?>
                    <div class="col-sm-10 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>PR ID</th>
                                    <th>Manager</th>
                                    <th>Executive</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pr->pr_id); ?></td>
                                        <td><label><input name="manager<?php echo e($pr->id); ?>" type="checkbox" value="manager" <?php if($pr->show_price_m == 'manager'): ?><?php echo e('checked'); ?><?php endif; ?>></label></td>
                                        <td><label><input name="executive<?php echo e($pr->id); ?>" type="checkbox" value="executive" <?php if($pr->show_price_e == 'executive'): ?><?php echo e('checked'); ?><?php endif; ?>></label></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-sm-10">
                        <div class="btn-button-group clearfix">
                            <button type="submit" class="btn btn-info btn-price">Approve</button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>