<style>
    tr,td{
        border: 1px solid red;
    }
</style>
<table>
    <tr>
        <td>PR ID</td>
        <td>PR Type</td>
        <td>Category</td>
        <td>Item Name</td>
        <td>Item Code</td>
        <td>Quantity</td>
    </tr>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($r->pr_id); ?></td>
            <td><?php echo e($r->pr_type); ?></td>
            <td><?php echo e($r->category); ?></td>
            <td><?php echo e($r->item_name); ?></td>
            <td><?php echo e($r->item_code); ?></td>
            <td><?php echo e($r->quantity); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>