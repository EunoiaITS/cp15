
<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <h3 class="text-uppercase color-bbc">Supplier List</h3>
                    <?php if(session()->has('success-message')): ?>
                        <p class="alert alert-success">
                            <?php echo e(session()->get('success-message')); ?>

                        </p>
                    <?php endif; ?>
                    <?php if(session()->has('error-message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(session()->get('error-message')); ?>

                        </p>
                    <?php endif; ?>
                    <!-- fliter button: new added -->
                     <div class="supplier-filter-option">
                        <select class="selectfilter" title="Filter">
                            <option class="asc" value="ascending">Ascending A-Z</option>
                            <option class="desc" value="descending">Descending Z-A</option>
                        </select>
                    </div>
                    <div class="col-sm-10 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table sort-table" id="sort-table">
                                <thead>
                                <tr>
                                    <th>Serial No</th>
                                    <th>Supplier Name</th>
                                    <th>Category</th>
                                    <th>Email Address </th>
                                    <th>Contact</th>
                                </tr>
                                </thead>
                                <tbody id="filtered-data">
                                <?php $j=1;?>
                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($j++); ?></td>
                                        <td id="name<?php echo e($res->id); ?>"><?php echo e($res->name); ?></td>
                                        <td id="category<?php echo e($res->id); ?>"><?php $__currentLoopData = $res->info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($in->category); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td id="email<?php echo e($res->id); ?>"><?php echo e($res->email); ?></td>
                                        <td id="contact<?php echo e($res->id); ?>"><?php $__currentLoopData = $res->info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($in->contact); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- pagination -->
                <div class="col-sm-10">
                    <div class="float-pagination">
                        <nav aria-label="Page navigation example">
                            <?php echo e($result->appends([ 'order' => $cur_order ])->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>