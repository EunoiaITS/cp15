<?php $__env->startSection('content'); ?>
<!-- content area-->
<div class="bbc-content-area mcw">
    <div class="container">
        <div class="row">
            <div class="col-sm-11 col-sm-offset-1">
                <div class="col-sm-10 padding-left-0">
                    <div class="create-qr clearfix">
                        <h3 class="text-uppercase color-bbc">Create Supplier List</h3>
                        <?php if(session()->has('error')): ?>
                            <p class="alert alert-success">
                                <?php echo e(session()->get('error')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if(session()->has('success-message')): ?>
                            <p class="alert alert-success">
                                <?php echo e(session()->get('success-message')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="alert alert-danger">
                                    <?php echo e($error); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <form action="<?php echo e(url('suppliers/add-supplier')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                            <div class="form-group clearfix">
                                <label for="supplier-name" class="label-d">Supplier Name <span class="fright">:</span></label>
                                <input type="text" name="name" class="form-control from-qr" id="supplier-name">
                            </div>
                            <div class="form-group live-search">
                                <label for="catagory-catagory" class="label-d">Category <span class="fright">:</span></label>
                                <select data-live-search="true" name="category" class="selectpicker" id="catagory-catagory">
                                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group clearfix">
                                <label for="pr-email" class="label-d">Email Address <span class="fright">:</span></label>
                                <input type="text" name="email" class="form-control from-qr" id="pr-email">
                            </div>
                            <div class="form-group clearfix">
                                <label for="pr-password" class="label-d">Password <span class="fright">:</span></label>
                                <input type="password" name="password" class="form-control from-qr" id="pr-password">
                            </div>
                            <div class="form-group clearfix">
                                <label for="pr-contact" class="label-d">Contact <span class="fright">:</span></label>
                                <input type="text" name="contact" class="form-control from-qr" id="pr-contact">
                            </div>
                            <input type="hidden" name="role" value="suppliers">
                            <input type="hidden" name="user_id" value="">
                            <div class="col-sm-9">
                                <button class="btn btn-info btn-price" style="float: right;">Add Supplier</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>