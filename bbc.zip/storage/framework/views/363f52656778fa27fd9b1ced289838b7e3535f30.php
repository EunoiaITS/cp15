
<?php $__env->startSection('content'); ?>
<div class="bbc-content-area mcw">
    <div class="container">
        <div class="row">
            <form method="post" action="<?php echo e(url('suppliers/invite-suppliers/')); ?>">
                <?php echo e(csrf_field()); ?>

            <div class="col-sm-11 col-sm-offset-1">
                <h3 class="text-uppercase color-bbc">Invite Suppliers</h3>
                <?php if(session()->has('error')): ?>
                    <p class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </p>
                <?php endif; ?>
                <?php if(session()->has('success-message')): ?>
                    <p class="alert alert-success">
                        <?php echo e(session()->get('success-message')); ?>

                    </p>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger">
                            <?php echo e($error); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <div class="col-sm-10 padding-left-0">
                    <div class="table table-responsive">

                        <table class="table">
                            <thead>
                            <tr>
                                <th>PR ID</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Selection</th>
                                <th>Select Supplier</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $qrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($qr->pr_id); ?></td>
                                <td><input type="text" name="start_date<?php echo e($qr->id); ?>" class="form-control from-qr datepicker-f" <?php if($qr->invite != null): ?><?php echo e('value="'.$qr->invite->start_date.'" readonly'); ?><?php endif; ?>></td>
                                <td><input type="text" name="end_date<?php echo e($qr->id); ?>" class="form-control from-qr datepicker-f" <?php if($qr->invite != null): ?><?php echo e('value="'.$qr->invite->end_date.'" readonly'); ?><?php endif; ?>></td>
                                <td><label><input name="suppliers<?php echo e($qr->id); ?>" type="checkbox" value="<?php echo e($qr->id); ?>"></label></td>
                                <td><button rel="<?php echo e($qr->id); ?>" type="button" class="btn btn-info btn-view-table open-popup select-suppliers">Supplier</button></td>
                                <input type="hidden" id="selected-suppliers<?php echo e($qr->id); ?>" name="selected-suppliers<?php echo e($qr->id); ?>" value="">
                                <?php if($qr->invite == null): ?><input type="hidden" id="action-add-<?php echo e($qr->id); ?>" name="action_add_<?php echo e($qr->id); ?>" value=""><?php endif; ?>
                            </tr>
                            <?php if($qr->invite != null): ?><input type="hidden" name="action<?php echo e($qr->id); ?>" value="edit"><?php endif; ?>
                            <span id="sup<?php echo e($qr->id); ?>" class="hidden"><?php if($qr->invite != null): ?><?php echo e($qr->invite->suppliers); ?><?php endif; ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-sm-10">
                    <div class="btn-button-group clearfix">
                        <button type="submit" class="btn btn-info btn-price">Send to Supplier</button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
</div>

<!--=============
Search popuppage
==================-->
<div class="popup-wrapper-view">
    <div class="popup-base">
        <div class="search-popup">
            <i class="close fa fa-remove"></i>
            <div class="row">
                <div class="search-destination">
                    <h2 class="search-title">Select Suppliers</h2>
                </div>
                <!-- header got search area -->
                <div class="popup-got-search">
                    <div class="table table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>List Of Suppliers</th>
                                <th>Select</th>
                            </tr>
                            </thead>
                            <tbody id="supplier-list">
                            </tbody>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span id="sup-id-<?php echo e($sup->id); ?>" class="hidden"><?php echo e($sup->id); ?></span>
                                <span id="sup-name-<?php echo e($sup->id); ?>" class="hidden"><?php echo e($sup->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <button id="confirm-select" name="modal" class="btn btn-info btn-popup close">Confirm</button>
                </div><!--// end header got search area -->
            </div>
        </div>
    </div>
</div><!-- Popup -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>