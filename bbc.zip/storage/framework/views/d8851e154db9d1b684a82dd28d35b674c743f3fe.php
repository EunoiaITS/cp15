
<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <h3 class="text-uppercase color-bbc">Tender Summary</h3>
                    <div class="col-sm-11 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>PR ID</th>
                                    <th>PR Type</th>
                                    <th>QR ID</th>
                                    <th>Items Name</th>
                                    <th>Item Code</th>
                                    <th>Quantity<th>
                                    <?php if(Auth::user()->role == 'director' || Auth::user()->role == 'manager' || Auth::user()->role == 'executive'): ?>
                                        <th>Unit Price</th>
                                    <?php endif; ?>
                                    <th>Supplier Name</th>
                                    <?php if(Auth::user()->role == 'director'): ?>
                                        <th>Download</th>
                                        <?php endif; ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $qrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php $__currentLoopData = $qr->qr_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($q->pr_id); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $qr->qr_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($q->pr_type); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php if($qr->supplier_details->qr_id != null): ?><?php echo e($qr->supplier_details->qr_id); ?><?php endif; ?></td>
                                        <td><?php $__currentLoopData = $qr->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item->item_name); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $qr->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item->item_no); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td><?php $__currentLoopData = $qr->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item->quantity); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                        <td></td>
                                        <?php if(Auth::user()->role == 'director'): ?>
                                        <td><?php echo e($qr->unit_price); ?></td>
                                            <?php elseif(Auth::user()->role == 'manager' || Auth::user()->role == 'executive'): ?>
                                            <td><?php if(Auth::user()->role == $qr->show_price || Auth::user()->role == $qr->show_price_e): ?><?php echo e($qr->unit_price); ?><?php endif; ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($qr->supplier->name); ?></td>
                                        <?php if(Auth::user()->role == 'director'): ?>
                                            <td><a href="#"><i class="fa fa-download"></i></a></td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>