<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <h3 class="text-uppercase color-bbc">QR Order</h3>
                    <div class="col-sm-8 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>PR ID</th>
                                    <th>PR Type</th>
                                    <th>Details</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $qrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td id="pr_id<?php echo e($qr->id); ?>"><?php echo e($qr->pr_id); ?></td>
                                        <span id="pr_type<?php echo e($qr->id); ?>" class="hidden"><?php echo e($qr->pr_type); ?></span>
                                        <td id="category<?php echo e($qr->id); ?>"><?php echo e($qr->category); ?></td>
                                        <?php $count = 0; ?>
                                        <?php $__currentLoopData = $qr->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $count++; ?>
                                            <span id="item<?php echo e($count.$qr->id); ?>" class="hidden item-id<?php echo e($qr->id); ?>"><?php echo e($item->id); ?></span>
                                            <span id="item-name<?php echo e($count.$qr->id); ?>" class="hidden"><?php echo e($item->item_name); ?></span>
                                            <span id="item-no<?php echo e($count.$qr->id); ?>" class="hidden"><?php echo e($item->item_no); ?></span>
                                            <span id="quantity<?php echo e($count.$qr->id); ?>" class="hidden"><?php echo e($item->quantity); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><button rel="<?php echo e($qr->id); ?>" id="view<?php echo e($qr->id); ?>" class="btn btn-info btn-view-table open-popup view-details">View</button></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--=============
            View Qr Order Popup:manager
            ==================-->
    <div class="popup-wrapper-view">
        <div class="popup-base">
            <div class="search-popup">
                <i class="close fa fa-remove"></i>
                <div class="row">
                    <div class="search-destination">
                        <h2 class="search-title">View QR Order</h2>
                    </div>
                    <!-- header got seach area -->
                    <div class="popup-got-search">
                        <div class="form-group clearfix">
                            <p class="label-d">PR ID <span class="fright">:</span></p>
                            <p id="view-pr-id" class="pr-text">12345</p>
                        </div>
                        <div class="form-group clearfix">
                            <p class="label-d">PR Type <span class="fright">:</span></p>
                            <p id="view-pr-type" class="pr-text">ABC</p>
                        </div>
                        <div class="form-group clearfix">
                            <p class="label-d">Category <span class="fright">:</span></p>
                            <p id="view-category" class="pr-text">Xyz</p>
                        </div>
                        <div class="col-sm-10 table-responsive" style="margin-top: 20px;">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Items Name</th>
                                    <th>Item Code</th>
                                    <th>Quantity</th>
                                </tr>
                                </thead>
                                <tbody id="add-item-table-view">
                                <tr>
                                    <td>01</td>
                                    <td>12345</td>
                                    <td>abc</td>
                                    <td>Xyz</td>
                                </tr>
                                <tr>
                                    <td>02</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div><!--// end header got search area -->
                </div>
            </div>
        </div>
    </div><!-- Popup -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>