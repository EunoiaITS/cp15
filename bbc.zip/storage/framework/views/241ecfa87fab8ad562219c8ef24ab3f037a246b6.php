<?php $__env->startSection('content'); ?>
<div class="bbc-content-area mcw">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="text-uppercase color-bbc">QR Order</h3>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger">
                            <?php echo e($error); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(session()->has('success-message')): ?>
                    <p class="alert alert-success">
                        <?php echo e(session()->get('success-message')); ?>

                    </p>
                <?php endif; ?>
                <?php if(session()->has('error-message')): ?>
                    <p class="alert alert-danger">
                        <?php echo e(session()->get('error-message')); ?>

                    </p>
                <?php endif; ?>
                <div class="col-sm-12 padding-left-0">
                    <div class="table table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>PR ID</th>
                                <th>Item Name</th>
                                <th>Item Code</th>
                                <th>Quantity</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Unit Price</th>
                                <th>Comments</th>
                                <th>Upload Files</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $qr_inv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qinv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $qinv->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!in_array($qrt->id, $quoted_items)): ?>
                                    <form action="<?php echo e(url('/supplier-controller/submit-qr')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <tr>
                                            <td><?php $__currentLoopData = $qinv->qr_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($qpr->pr_id); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><input type="hidden" name="item_id" value="<?php echo e($qrt->id); ?>"></td>
                                            <td><?php echo e($qrt->item_name); ?></td>
                                            <td><?php echo e($qrt->item_no); ?></td>
                                            <td><?php echo e($qrt->quantity); ?></td>
                                            <td><?php echo e(date('m/d/Y',strtotime($qinv->start_date))); ?></td>
                                            <td><?php echo e(date('m/d/Y',strtotime($qinv->end_date))); ?></td>
                                            <td><input type="text" name="unit_price" class="form-control from-btn-supplier from-qr" required></td>
                                            <td><input type="text" name="comment" class="form-control from-qr from-supplier"> </td>
                                            <td>
                                                <div class="file btn btn-sm btn-primary btn-supplier">
                                                    <div class="upload-icon"><i class="fa fa-cloud-upload" aria-hidden="true"></i></div><span>Upload</span>
                                                    <input type="file" name="attachment" class="input-upload" name="file">
                                                </div>
                                            </td>
                                            <td><button type="submit" class="btn btn-primary btn-supplier input-upload">Submit</button></td>
                                        </tr>
                                    </form>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- pagination -->
            <div class="col-sm-10">
                <div class="float-pagination">
                    <nav aria-label="Page navigation example">
                        <?php echo e($qr_inv->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>