<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-11 col-sm-offset-1">
                    <h3 class="text-uppercase color-bbc">QR Order</h3>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="alert alert-danger">
                                <?php echo e($error); ?>

                            </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(session()->has('success-message')): ?>
                        <p class="alert alert-success">
                            <?php echo e(session()->get('success-message')); ?>

                        </p>
                    <?php endif; ?>
                    <?php if(session()->has('error-message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(session()->get('error-message')); ?>

                        </p>
                    <?php endif; ?>
                    <div class="col-sm-11 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>PR ID</th>
                                    <th>Item Name</th>
                                    <th>Item Code</th>
                                    <th>Quantity</th>
                                    <th>File (BBC)</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Place Quotation</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($item->check)): ?>
                                        <?php if($item->check == 'yes'): ?>
                                            <tr>
                                                <td><?php echo e($item->qr->pr_id); ?></td>
                                                <td><?php echo e($item->item_name); ?></td>
                                                <td><?php echo e($item->item_no); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td><?php if($item->item_file != ''): ?><a href="<?php echo e(asset('public/uploads/items/'.$item->item_file)); ?>" target="_blank" download><button class="btn btn-primary btn-supplier input-upload"><i class="fa fa-download"></i></button></a><?php endif; ?></td>
                                                <td><?php if(isset($item->details->start_date)): ?><?php echo e(date('d/m/Y',strtotime($item->details->start_date))); ?><?php endif; ?></td>
                                                <td><?php if(isset($item->details->end_date)): ?><?php echo e(date('d/m/Y',strtotime($item->details->end_date))); ?><?php endif; ?></td>
                                                <td><button type="button" class="btn btn-primary btn-supplier input-upload" data-toggle="modal" data-target="#prmodal<?php echo e($item->id); ?>" rel="<?php echo e($item->id); ?>">Add Quotation</button></td>
                                            </tr>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- pagination -->
                <div class="col-sm-10">
                    <div class="float-pagination">
                        <nav aria-label="Page navigation example">
                            <?php echo e($items->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- place quatation -->
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form id="submit-qr<?php echo e($item->id); ?>" action="<?php echo e(url('/supplier-controller/submit-qr/')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div id="prmodal<?php echo e($item->id); ?>" class="modal fade bs-example-modal-lg popup-prid-comparison" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                        <div class="popup-base">
                            <div class="search-popup">
                                <i class="close fa fa-remove close" data-dismiss="modal" aria-label="Close"></i>
                                <div class="row">
                                    <div class="search-destination">
                                        <h2 class="search-title">Place Quatation</h2>
                                    </div>
                                    <!-- header got seach area -->
                                    <div class="popup-got-search">
                                        <div class="table table-responsive">
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th>Origin</th>
                                                    <th>Genuine</th>
                                                    <th>OEM</th>
                                                    <th>Brand</th>
                                                    <th>Deliver Date</th>
                                                    <th>Unit Price (including tax)(RM)</th>
                                                    <th>Comments</th>
                                                    <th>Upload File</th>
                                                </tr>
                                                </thead>
                                                <tbody id="add-item-table-item<?php echo e($item->id); ?>">
                                                <tr>
                                                    <td><input type="text" name="origin0" class="form-control from-btn-supplier from-qr"><input type="hidden" name="item_id0" value="<?php echo e($item->id); ?>"></td>
                                                    <td><input type="text" name="genuine0" class="form-control from-btn-supplier from-qr"></td>
                                                    <td><input type="text" name="oem0" class="form-control from-btn-supplier from-qr"></td>
                                                    <td><input type="text" name="brand0" class="form-control from-btn-supplier from-qr"></td>
                                                    <td><input type="text" name="delivery_date0" class="form-control from-qr from-supplier datepicker-f"></td>
                                                    <td><input type="number" placeholder="0.0" name="unit_price0" class="form-control from-btn-supplier from-qr unit-price" required></td>
                                                    <td><input type="text" name="comment0" class="form-control from-qr from-supplier"><input id="total" type="hidden" name="count" value="0"></td>
                                                    <td>
                                                        <div class="file btn btn-sm btn-primary btn-supplier">
                                                            <div class="upload-icon"><i class="fa fa-cloud-upload" aria-hidden="true"></i></div><span>Upload</span>
                                                            <input type="file" name="attachment0" class="input-upload">
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="place-quatation-submit">
                                            <button type="button" class="btn btn-info btn-view-table edit-qr add-item-create" rel="<?php echo e($item->id); ?>">Add Item</button>
                                            <button type="button" class="btn btn-info btn-view-table confirm" data-toggle="modal" data-target="#confirm<?php echo e($item->id); ?>" rel="<?php echo e($item->id); ?>">Submit</button>
                                            <button type="button" class="btn btn-info btn-view-table  edit-qr">Cancel</button>
                                        </div>
                                    </div><!--// end header got search area -->
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- submit popup -->
    <div id="confirm<?php echo e($item->id); ?>" class="modal fade bs-example-modal-lg popup-wrapper-delete" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="popup-base">
            <div class="search-popup">
                <i class="close fa fa-remove"></i>
                <div class="row">
                    <!-- header got seach area -->
                    <div class="popup-got-search">
                        <p>Are you sure you want to submit ?</p>
                    </div><!--// end header got search area -->
                        <div class="col-sm-12">
                            <div class="btn-button-group clearfix">
                                <button type="submit" class="btn btn-info btn-price" form="submit-qr<?php echo e($item->id); ?>">Yes</button>
                                <button type="button" class="btn btn-info btn-popup close">No</button>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>