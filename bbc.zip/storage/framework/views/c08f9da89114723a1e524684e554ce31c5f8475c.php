<?php $__env->startSection('content'); ?>
    <!-- content area-->
    <div class="bbc-content-area mcw">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-sm-offset-0">
                    <h3 class="text-uppercase color-bbc">Supplier Quotations</h3>
                    <?php if(session()->has('success-message')): ?>
                        <p class="alert alert-success">
                            <?php echo e(session()->get('success-message')); ?>

                        </p>
                    <?php endif; ?>
                    <?php if(session()->has('error-message')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(session()->get('error-message')); ?>

                        </p>
                    <?php endif; ?>
                    <div class="col-sm-11 padding-left-0">
                        <div class="table table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>PR ID</th>
                                    <th>PR Type</th>
                                    <th>Issue Date</th>
                                    <th>End Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $count = 0; ?>
                                <?php $__currentLoopData = $allInvites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($invite->invited) && $invite->invited == 'yes'): ?>
                                        <?php $count++; ?>
                                        <tr>
                                            <td><?php echo e($count); ?></td>
                                            <td><a style="cursor: pointer" class="pr-modal" rel="<?php echo e($count); ?>" data-toggle="modal" data-target="#myModal<?php echo e($count); ?>"><?php echo e($invite->qr_details->pr_id); ?></a></td>
                                            <td><?php echo e($invite->qr_details->pr_type); ?></td>
                                            <td><?php echo e(date('d-M-Y', strtotime($invite->start_date))); ?></td>
                                            <td><?php echo e(date('d-M-Y', strtotime($invite->end_date))); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- pagination -->
                    <div class="col-sm-10">
                        <div class="float-pagination">
                            <nav aria-label="Page navigation example">
                                <?php echo e($allInvites->links()); ?>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--
   PR ID popup content
   ========================-->
    <?php $j=0;?>
    <?php $__currentLoopData = $allInvites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($invite->invited) && $invite->invited == 'yes'): ?>
            <?php $j++?>
            <div id="myModal<?php echo e($j); ?>" class="popup-prid-comparison">
                <form action="<?php echo e(url('/approve-quotations')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="popup-base">
                        <div class="search-popup">
                            <i class="close fa fa-remove" data-dismiss="modal"></i>
                            <div class="row">
                                <div class="search-destination">
                                    <h2 class="pr-title"><span class="pr-id">PR ID: <?php echo e($invite->qr_details->pr_id); ?></span><span class="prtext"></span></h2>
                                </div>
                                <!-- header got seach area -->
                                <div class="popup-got-search popup-pie clearfix">
                                    <div class="table table-responsive">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th style="text-align: center;">No</th>
                                                <th style="text-align: center;">Item Code</th>
                                                <th style="text-align: center;">Item Name</th>
                                                <th style="text-align: center;">Quantity</th>
                                                <?php if(Auth::user()->role == 'manager' || Auth::user()->role == 'executive'): ?>
                                                <th>Unit Price</th>
                                                <?php endif; ?>
                                                <th style="text-align: center;">Supplier Name</th>
                                                <th style="text-align: center;">Comment</th>
                                                <th style="text-align: center;">File</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $c = 0;?>
                                            <?php $__currentLoopData = $invite->qr_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($qr->ex) && ($qr->ex == 'yes')): ?>
                                                    <?php if(isset($qr->supplierQuote)): ?>
                                                        <?php $__currentLoopData = $qr->supplierQuote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $c++;?>
                                                            <tr>
                                                                <td style="text-align: center;"><?php echo e($c); ?></td>
                                                                <td style="text-align: center;"><?php echo e($qr->item_no); ?></td>
                                                                <td style="text-align: center;"><?php echo e($qr->item_name); ?></td>
                                                                <td style="text-align: center;"><?php echo e($qr->quantity); ?></td>
                                                                <?php if(Auth::user()->role == 'manager' || Auth::user()->role == 'executive'): ?>
                                                                <td><?php if(Auth::user()->role == $sq->show_price || Auth::user()->role == $sq->show_price_e): ?><?php echo e($sq->unit_price); ?><?php endif; ?></td>
                                                                <?php endif; ?>
                                                                <td style="text-align: center;"><?php echo e($sq->sup_details->name); ?></td>
                                                                <td style="text-align: center;"><?php echo e($sq->comment); ?></td>
                                                                <td style="text-align: center;"><a href="<?php if($sq->file != null): ?><?php echo e(URL::asset('/public/uploads/'.$sq->file)); ?><?php endif; ?>" target="_blank"><?php if($sq->file != null){echo "View";}?></a></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!--// end header got search area -->
                            </div>
                        </div>
                    </div>
                </form>
            </div><!-- Popup -->
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>